<div class="onlymatt-admin-frontend">
    <h3>Panneau d'Administration ONLYMATT AI</h3>
    <p>Vous avez les permissions nécessaires pour accéder aux fonctionnalités avancées.</p>

    <div class="admin-actions">
        <a href="<?php echo admin_url('admin.php?page=onlymatt-ai'); ?>" class="button button-primary">Accéder au Tableau de Bord</a>
        <a href="<?php echo admin_url('admin.php?page=onlymatt-ai-chat'); ?>" class="button">Chat Admin</a>
        <a href="<?php echo admin_url('admin.php?page=onlymatt-ai-tasks'); ?>" class="button">Gestion des Tâches</a>
    </div>
</div>