<div class="onlymatt-chat-container">
    <div class="onlymatt-chat-header">
        Chat avec ONLYMATT AI
    </div>
    <div class="messages">
        <!-- Messages will appear here -->
    </div>
    <form class="onlymatt-chat-form">
        <input type="text" name="message" placeholder="Tapez votre message..." required />
        <button type="submit">Envoyer</button>
    </form>
</div>